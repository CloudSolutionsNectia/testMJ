<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>SLA Defecto</label>
    <protected>false</protected>
    <values>
        <field>SLA_Atencion__c</field>
        <value xsi:type="xsd:double">0.5</value>
    </values>
    <values>
        <field>SLA_Resolucion__c</field>
        <value xsi:type="xsd:double">8.0</value>
    </values>
</CustomMetadata>
