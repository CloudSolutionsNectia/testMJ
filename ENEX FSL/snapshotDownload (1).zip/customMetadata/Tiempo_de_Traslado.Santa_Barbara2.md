<?xml version="1.0" encoding="UTF-8"?>
<CustomMetadata xmlns="http://soap.sforce.com/2006/04/metadata" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:xsd="http://www.w3.org/2001/XMLSchema">
    <label>Santa Bárbara</label>
    <protected>false</protected>
    <values>
        <field>Tiempo_en_Horas__c</field>
        <value xsi:type="xsd:double">4.0</value>
    </values>
</CustomMetadata>
